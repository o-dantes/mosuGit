﻿namespace mosu
{
    using FastReport.DataVisualization.Charting;
    using System;
    using System.Windows.Forms;
    using System.Windows.Forms.Charting;
    namespace HydraulicSystem
    {
        public partial class MainForm : Form
        {
            private double z1 = 0.3;
            private double z2 = 0.1;
            private double alpha_in_1 = 0.0583;
            private double alpha_in_2 = 0.0583;
            private double alpha_12, alpha_out;
            private double p_in_1_0 = 2, p_in_2_0 = 2, p_out_0 = 0.05;
            private double x_in_1_0 = Math.PI * Math.Pow(0.04, 2) / 4;
            private double x_in_2_0 = Math.PI * Math.Pow(0.03, 2) / 4;
            private double x_12_0 = Math.PI * Math.Pow(0.03, 2) / 4;
            private double x_out_0 = Math.PI * Math.Pow(0.02, 2) / 4;
            private double F1 = Math.PI * Math.Pow(0.2, 2) / 4;
            private double F2 = Math.PI * Math.Pow(0.25, 2) / 4;
            private System.Windows.Forms.Timer timer;
            private Chart chart1;
            private Button btnIncreaseIn1, btnDecreaseIn1, btnIncreaseIn2, btnDecreaseIn2;
            private Button btnIncrease12, btnDecrease12, btnIncreaseOut, btnDecreaseOut;

            public MainForm()
            {
                //InitializeComponent();
                InitializeChart();
                InitializeControls();
                InitializeTimer();
            }

            private void InitializeChart()
            {
                chart1 = new Chart
                {
                    Dock = DockStyle.Top,
                    Height = 300
                };

                ChartArea chartArea = new ChartArea();
                chart1.ChartAreas.Add(chartArea);

                chart1.Series.Clear();
                var series1 = new Series("z1") { ChartType = SeriesChartType.Line };
                var series2 = new Series("z2") { ChartType = SeriesChartType.Line };
                chart1.Series.Add(series1);
                chart1.Series.Add(series2);

                Controls.Add(chart1);  // Add the chart to the form
            }

            private void InitializeControls()
            {
                btnIncreaseIn1 = new Button { Text = "Increase Inlet 1", Left = 10, Top = 300, Width = 120 };
                btnDecreaseIn1 = new Button { Text = "Decrease Inlet 1", Left = 140, Top = 300, Width = 120 };
                btnIncreaseIn2 = new Button { Text = "Increase Inlet 2", Left = 10, Top = 330, Width = 120 };
                btnDecreaseIn2 = new Button { Text = "Decrease Inlet 2", Left = 140, Top = 330, Width = 120 };
                btnIncrease12 = new Button { Text = "Increase Flow 1-2", Left = 10, Top = 360, Width = 120 };
                btnDecrease12 = new Button { Text = "Decrease Flow 1-2", Left = 140, Top = 360, Width = 120 };
                btnIncreaseOut = new Button { Text = "Increase Outlet", Left = 10, Top = 390, Width = 120 };
                btnDecreaseOut = new Button { Text = "Decrease Outlet", Left = 140, Top = 390, Width = 120 };

                btnIncreaseIn1.Click += (s, e) => x_in_1_0 *= 1.1;
                btnDecreaseIn1.Click += (s, e) => x_in_1_0 *= 0.9;
                btnIncreaseIn2.Click += (s, e) => x_in_2_0 *= 1.1;
                btnDecreaseIn2.Click += (s, e) => x_in_2_0 *= 0.9;
                btnIncrease12.Click += (s, e) => x_12_0 *= 1.1;
                btnDecrease12.Click += (s, e) => x_12_0 *= 0.9;
                btnIncreaseOut.Click += (s, e) => x_out_0 *= 1.1;
                btnDecreaseOut.Click += (s, e) => x_out_0 *= 0.9;

                Controls.Add(btnIncreaseIn1);
                Controls.Add(btnDecreaseIn1);
                Controls.Add(btnIncreaseIn2);
                Controls.Add(btnDecreaseIn2);
                Controls.Add(btnIncrease12);
                Controls.Add(btnDecrease12);
                Controls.Add(btnIncreaseOut);
                Controls.Add(btnDecreaseOut);
            }

            private void InitializeTimer()
            {
                timer = new System.Windows.Forms.Timer();
                timer.Interval = 100;
                timer.Tick += UpdateSystem;
                timer.Start();
            }

            private void UpdateSystem(object sender, EventArgs e)
            {
                double dz1_dt = (alpha_in_1 * x_in_1_0 * Math.Sqrt(p_in_1_0) + alpha_in_2 * x_in_2_0 * Math.Sqrt(p_in_2_0 - z1) - alpha_12 * x_12_0 * Math.Sqrt(z1 - z2)) / F1;
                double dz2_dt = (alpha_12 * x_12_0 * Math.Sqrt(z1 - z2) - alpha_out * x_out_0 * Math.Sqrt(z2 - p_out_0)) / F2;
                z1 += dz1_dt * 0.1;
                z2 += dz2_dt * 0.1;
                chart1.Series["z1"].Points.AddY(z1);
                chart1.Series["z2"].Points.AddY(z2);
            }
        }
    }

}
