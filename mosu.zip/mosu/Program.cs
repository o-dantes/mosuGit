﻿using mosu.HydraulicSystem;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace mosu
{
    internal static class Program
    {
        [STAThread]
        static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);

            // Create both forms
            Form1 form1 = new Form1();
            MainForm mainForm = new MainForm();

            // Show both forms
            form1.Show();
            mainForm.Show();

            // Start the application message loop with one main form
            Application.Run();
        }
    }
}

